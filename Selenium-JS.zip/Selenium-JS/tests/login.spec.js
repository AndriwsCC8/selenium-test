const {Builder, By} = require('selenium-webdriver');
describe('Login', () => {
    it('should login with valid credentials', async () => {
        let driver = new Builder().forBrowser("chrome").build();
        await driver.get('https://www.saucedemo.com/')

        await driver.findElement(By.id("user-name")).sendKeys('standard_user');
        await driver.findElement(By.css("#password")).sendKeys('secret_sauce');
        await driver.findElement(By.css('[id="login-button"]')).click();
        await driver.sleep(5000);
        await driver.quit();
        /*cy.visit('https://www.saucedemo.com/');
        cy.get('#user-name').type('standard_user');
        cy.get('#password').type('secret_sauce');
        cy.get('#login-button').click();
        cy.url().should('include', '/inventory.html');*/
    });
});